/******************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file Gpio.c
 **
 ** GPIO driver API.
 ** @link Driver Group Some description @endlink
 **
 **   - 2020-04-22  1.0  xl First version
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "gpio.h"

/**
 *******************************************************************************
 ** \addtogroup GpioGroup
 ******************************************************************************/
//@{

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define GPIO_MODE           (0xF)
#define GPIO_MODE_OD        (0xF0)
#define GPIO_MODE_OUTPUT    (0x2)
#define GPIO_MODE_AF        (0x3)

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')         *
 ******************************************************************************/

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 *******************************************************************************
 ** \brief GPIO 初始化
 **
 ** \param [in]  GPIOx          @ref M0P_GPIO_TypeDef
 ** \param [in]  pstcGpioInit   @ref stc_gpio_init_t
 **
 ** \retval  None
 ******************************************************************************/
void GPIO_Init(M0P_GPIO_TypeDef *GPIOx, stc_gpio_init_t *pstcGpioInit)
{
    ///< ANALOG
    if(GPIO_MODE_ANALOG == (pstcGpioInit->u32Mode&GPIO_MODE))
    {
        REG_SETBITS(GPIOx->ADS, pstcGpioInit->u32Pin);
    }
    else
    {
        REG_CLEARBITS(GPIOx->ADS, pstcGpioInit->u32Pin);
    }
    
    ///< INPUT
    if(GPIO_MODE_INPUT == (pstcGpioInit->u32Mode&GPIO_MODE))
    {
        REG_SETBITS(GPIOx->DIR, pstcGpioInit->u32Pin);
    }
    
    ///< OUTPUT
    if(GPIO_MODE_OUTPUT == (pstcGpioInit->u32Mode&GPIO_MODE))
    {
        REG_CLEARBITS(GPIOx->DIR, pstcGpioInit->u32Pin);
    }
    
    ///< OPENDRAIN or PUSH-PULL
    if(pstcGpioInit->u32Mode&GPIO_MODE_OD)
    {
        REG_SETBITS(GPIOx->OPENDRAIN, pstcGpioInit->u32Pin);
    }
    else
    {
        REG_CLEARBITS(GPIOx->OPENDRAIN, pstcGpioInit->u32Pin);
        
        ///< PUSH-PULL TYPE
        if(GPIO_PULL_UP == pstcGpioInit->u32Pull)
        {
            REG_SETBITS(GPIOx->PU, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->PU, pstcGpioInit->u32Pin);
        }
    }
        
    ///< EXTI
    if(pstcGpioInit->u32Mode&GPIO_MODE_EXTI)
    {
        if(pstcGpioInit->u32ExtI&GPIO_EXTI_RISING)
        {
            REG_SETBITS(GPIOx->RISEIE, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->RISEIE, pstcGpioInit->u32Pin);
        }
        
        if(pstcGpioInit->u32ExtI&GPIO_EXTI_FALLING)
        {
            REG_SETBITS(GPIOx->FALLIE, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->FALLIE, pstcGpioInit->u32Pin);
        }
        
        if(pstcGpioInit->u32ExtI&GPIO_EXTI_HIGH)
        {
            REG_SETBITS(GPIOx->HIGHIE, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->HIGHIE, pstcGpioInit->u32Pin);
        }
        
        if(pstcGpioInit->u32ExtI&GPIO_EXTI_LOW)
        {
            REG_SETBITS(GPIOx->LOWIE, pstcGpioInit->u32Pin);
        }
        else
        {
            REG_CLEARBITS(GPIOx->LOWIE, pstcGpioInit->u32Pin);
        }
    }
     
}


/**
 *******************************************************************************
 ** \brief GPIO PIN脚中断状态获取
 **
 ** \param [in]  GPIOx          @ref M0P_GPIO_TypeDef
 ** \param [in]  u32Pin         @ref GPIO_PINs_definition
 **
 ** \retval  0表示未发生中断，非0表示产生中断
 ******************************************************************************/
uint32_t GPIO_ExtIrqStateGet(M0P_GPIO_TypeDef *GPIOx, uint32_t u32Pin)
{    
    return (uint32_t)REG_READBITS(GPIOx->IFR, u32Pin);
}

/**
 *******************************************************************************
 ** \brief GPIO PIN脚中断状态清除
 **
 ** \param [in]  GPIOx          @ref M0P_GPIO_TypeDef
 ** \param [in]  u32Pin         @ref GPIO_PINs_definition
 **
 ** \retval  None
 ******************************************************************************/
void GPIO_ExtIrqStateClear(M0P_GPIO_TypeDef *GPIOx, uint32_t u32Pin)
{
    REG_CLEARBITS(GPIOx->ICR, u32Pin);
}




//@} // GpioGroup


/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/


/******************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file adc.c
 **
 ** ADC driver API.
 **
 **   - 2020-06-15 Chenw    First Version
 **
 ******************************************************************************/

/******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"

/**
 ******************************************************************************
 ** \addtogroup AdcGroup
 ******************************************************************************/
//@{

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
  
/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 *****************************************************************************/

/**
 * \brief
 *          ADC初始化
 *
 * \param   [in]  pstcAdcCfg  ADC配置指针
 *
 * \retval  en_result_t  Ok:  配置成功
 * \retval  en_result_t  ErrorInvalidParameter: 无效参数
 */
en_result_t ADC_Init(M0P_ADC_TypeDef *ADCx, stc_adc_cfg_t* pstcAdcCfg)
{
    if (NULL == pstcAdcCfg)
    {
        return ErrorInvalidParameter;
    }
    
    REG_MODIFY(ADCx->CR0, 
                 ADC_CR0_CKDIV
               | ADC_CR0_REF
               | ADC_CR0_SAM
               | ADC_CR0_EN
               , 
                 pstcAdcCfg->u32ClkDiv
               | pstcAdcCfg->u32RefVolSel
               | pstcAdcCfg->u32SampCycleSel
               | ADC_CR0_EN);
    
    REG_MODIFY(ADCx->CR1, ADC_CR1_CHSEL,  pstcAdcCfg->u32InputSource);
    
    REG_MODIFY(ADCx->EXTTRIGGER, ADC_EXTTRIGGER_TRIGSEL,  pstcAdcCfg->u32ExtTriggerSource);

    delay10us(1);
    return Ok;
}

/**
 ***********************************************************************************************
 ** \brief  设定ADC采样周期
 ** \param  [in] ADCx：ADC结构体变量
 ** \param  [in] 设定值如下：
 **         @arg @ref ADC_SAMPLINGTIME_6CYCLE
 **         @arg @ref ADC_SAMPLINGTIME_8CYCLE
 **         @arg @ref ADC_SAMPLINGTIME_11CYCLE
 **         @arg @ref ADC_SAMPLINGTIME_12CYCLE

 ** \retval NULL
 ***********************************************************************************************/
void ADC_SetSampCycle(M0P_ADC_TypeDef *ADCx, uint32_t u32SampCycle)
{
    REG_MODIFY(ADCx->CR0, ADC_CR0_SAM, u32SampCycle);
}

/**
 ***********************************************************************************************
 ** \brief  获取ADC采样周期
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 返回值如下:
 **         @arg @ref ADC_SAMPLINGTIME_6CYCLE
 **         @arg @ref ADC_SAMPLINGTIME_8CYCLE
 **         @arg @ref ADC_SAMPLINGTIME_11CYCLE
 **         @arg @ref ADC_SAMPLINGTIME_12CYCLE
 ***********************************************************************************************/
uint32_t ADC_GetSampCycle(M0P_ADC_TypeDef *ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR0, ADC_CR0_SAM));    
}

/**
 ***********************************************************************************************
 ** \brief  设定ADC采样周期
 ** \param  [in] ADCx：ADC结构体变量
 ** \param  [in] 设定值如下：
 **         @arg @ref ADC_REF_VOLTAGE_EXREF
 **         @arg @ref ADC_REF_VOLTAGE_AVCC

 ** \retval NULL
 ***********************************************************************************************/
void ADC_SetRefVol(M0P_ADC_TypeDef *ADCx, uint32_t u32RefVol)
{
    REG_MODIFY(ADCx->CR0, ADC_CR0_REF, u32RefVol);
}

/**
 ***********************************************************************************************
 ** \brief  获取ADC采样周期
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 返回值如下:
 **         @arg @ref ADC_REF_VOLTAGE_EXREF
 **         @arg @ref ADC_REF_VOLTAGE_AVCC
 ***********************************************************************************************/
uint32_t ADC_GetRefVol(M0P_ADC_TypeDef *ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR0, ADC_CR0_REF));    
}


/**
 ***********************************************************************************************
 ** \brief  设定ADC采样周期
 ** \param  [in] ADCx：ADC结构体变量
 ** \param  [in] 设定值如下：
 **         @arg @ref ADC_CLOCK_PCLK_DIV1
 **         @arg @ref ADC_CLOCK_PCLK_DIV2
 **         @arg @ref ADC_CLOCK_PCLK_DIV4
 **         @arg @ref ADC_CLOCK_PCLK_DIV8
 **         @arg @ref ADC_CLOCK_PCLK_DIV16
 **         @arg @ref ADC_CLOCK_PCLK_DIV32
 **         @arg @ref ADC_CLOCK_PCLK_DIV64
 **         @arg @ref ADC_CLOCK_PCLK_DIV128

 ** \retval NULL
 ***********************************************************************************************/
void ADC_SetClockDiv(M0P_ADC_TypeDef *ADCx, uint32_t u32ClockDiv)
{
    REG_MODIFY(ADCx->CR0, ADC_CR0_CKDIV, u32ClockDiv);
}

/**
 ***********************************************************************************************
 ** \brief  获取ADC采样周期
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 返回值如下:
 **         @arg @ref ADC_CLOCK_PCLK_DIV1
 **         @arg @ref ADC_CLOCK_PCLK_DIV2
 **         @arg @ref ADC_CLOCK_PCLK_DIV4
 **         @arg @ref ADC_CLOCK_PCLK_DIV8
 **         @arg @ref ADC_CLOCK_PCLK_DIV16
 **         @arg @ref ADC_CLOCK_PCLK_DIV32
 **         @arg @ref ADC_CLOCK_PCLK_DIV64
 **         @arg @ref ADC_CLOCK_PCLK_DIV128
 ***********************************************************************************************/
uint32_t ADC_GetClockDiv(M0P_ADC_TypeDef *ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR0, ADC_CR0_CKDIV));    
}

/**
 ***********************************************************************************************
 ** \brief  启动 ADC单次转换
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval NULL
 ***********************************************************************************************/
void ADC_StartSingleConversion(M0P_ADC_TypeDef *ADCx)
{
    REG_SETBITS(ADCx->START, ADC_START_START);
}

/**
 ***********************************************************************************************
 ** \brief  启动 ADC持续转换
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval NULL
 ***********************************************************************************************/
void ADC_StartContinuousConversion(M0P_ADC_TypeDef *ADCx)
{
    REG_SETBITS(ADCx->ALLSTART, ADC_ALLSTART_START);
}

/**
 ***********************************************************************************************
 ** \brief  停止 ADC 持续转换
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval NULL
 ***********************************************************************************************/
void ADC_StopContinuousConversion(M0P_ADC_TypeDef *ADCx)
{
    REG_CLEARBITS(ADCx->ALLSTART, ADC_ALLSTART_START);
}

/**
 ***********************************************************************************************
 ** \brief  配置ADC转换通道
 ** \param  [in] ADCx：ADC结构体变量
 ** \param  u32AdcSampInput   设定值如下：
 **         @arg @ref ADC_EXINPUT_PC04
 **         @arg @ref ADC_EXINPUT_PC06
 **         @arg @ref ADC_EXINPUT_PD02
 **         @arg @ref ADC_EXINPUT_PD03
 **         @arg @ref ADC_EXINPUT_PD04
 **         @arg @ref ADC_EXINPUT_PD05
 **         @arg @ref ADC_EXINPUT_PD06
 **         @arg @ref ADC_EXINPUT_PA01
 **         @arg @ref ADC_EXINPUT_PA02
 **         @arg @ref ADC_EXINPUT_PB05
 **         @arg @ref ADC_EXINPUT_PB04
 **         @arg @ref ADC_EXINPUT_PB02
 **         @arg @ref ADC_EXINPUT_PB01
 **         @arg @ref ADC_EXINPUT_PB00
 **         @arg @ref ADC_EXINPUT_VREF_0p9

 ** \retval NULL
 ***********************************************************************************************/
void ADC_SetInputSource(M0P_ADC_TypeDef *ADCx, uint32_t u32AdcSampInput)
{
    REG_MODIFY(ADCx->CR1, ADC_CR1_CHSEL, u32AdcSampInput);
}

/**
 ***********************************************************************************************
 ** \brief  获取 指定通道的输入选择
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 返回值: 输入选择
 **         @arg @ref ADC_EXINPUT_PC04
 **         @arg @ref ADC_EXINPUT_PC06
 **         @arg @ref ADC_EXINPUT_PD02
 **         @arg @ref ADC_EXINPUT_PD03
 **         @arg @ref ADC_EXINPUT_PD04
 **         @arg @ref ADC_EXINPUT_PD05
 **         @arg @ref ADC_EXINPUT_PD06
 **         @arg @ref ADC_EXINPUT_PA01
 **         @arg @ref ADC_EXINPUT_PA02
 **         @arg @ref ADC_EXINPUT_PB05
 **         @arg @ref ADC_EXINPUT_PB04
 **         @arg @ref ADC_EXINPUT_PB02
 **         @arg @ref ADC_EXINPUT_PB01
 **         @arg @ref ADC_EXINPUT_PB00
 **         @arg @ref ADC_EXINPUT_VREF_0p9

 ***********************************************************************************************/
uint32_t ADC_GetInputSource(M0P_ADC_TypeDef *ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR1, ADC_CR1_CHSEL));    
}

/**
 ***********************************************************************************************
 ** \brief  获取 ADC转换结果
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 返回值: 转换结果

 ***********************************************************************************************/
uint32_t ADC_GetResult(M0P_ADC_TypeDef *ADCx)
{
    return (uint32_t)(REG_READ(ADCx->RESULT));    
}

/**
 ***********************************************************************************************
 ** \brief  设定 ADC转换外部中断触发源
 ** \param  [in] ADCx：ADC结构体变量
 ** \param  [in] u32ExtTriggerSource：触发源，下面单个值或多个相或的值
 **         @arg @ref ADC_EXTTRIGGER_ATIM3    ATimer3触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_GTIM     GTimer溢出触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PB03     PB03中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PB04     PB04中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PC03     PC03中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PC04     PC04中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PD03     PD03中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PD04     PD04中断触发ADC转换

 ** \retval NULL
 ***********************************************************************************************/
void ADC_SetExtTriggerSource(M0P_ADC_TypeDef *ADCx, uint32_t u32ExtTriggerSource)
{
    REG_WRITE(ADCx->EXTTRIGGER, u32ExtTriggerSource);
}

/**
 ***********************************************************************************************
 ** \brief  获取  ADC转换外部中断触发源
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 返回值: 触发源，下面单个值或多个相或的值
 **         @arg @ref ADC_EXTTRIGGER_ATIM3    ATimer3触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_GTIM     GTimer溢出触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PB03     PB03中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PB04     PB04中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PC03     PC03中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PC04     PC04中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PD03     PD03中断触发ADC转换
 **         @arg @ref ADC_EXTTRIGGER_PD04     PD04中断触发ADC转换
 ***********************************************************************************************/
uint32_t ADC_GetExtTriggerSource(M0P_ADC_TypeDef *ADCx)
{
    return (uint32_t)(REG_READ(ADCx->EXTTRIGGER));    
}

/**
 ***********************************************************************************************
 ** \brief  开启ADC模块
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval NULL
 ***********************************************************************************************/
void ADC_Enable(M0P_ADC_TypeDef *ADCx)
{
    REG_SETBITS(ADCx->CR0, ADC_CR0_EN);
}

/**
 ***********************************************************************************************
 ** \brief  禁止ADC模块
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval NULL
 ***********************************************************************************************/
void ADC_Disable(M0P_ADC_TypeDef *ADCx)
{
    REG_CLEARBITS(ADCx->CR0, ADC_CR0_EN);    
}

/**
 ***********************************************************************************************
 ** \brief  检查ADC模块是否已开启
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 0：未开启； 非0：已开启
 ***********************************************************************************************/
uint32_t ADC_IsEnable(M0P_ADC_TypeDef *ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->CR0, ADC_CR0_EN) == ADC_CR0_EN);    
}

/**
 ***********************************************************************************************
 ** \brief  获取 ADC一次转换完成标志
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 返回值: 0或者1

 ***********************************************************************************************/
uint32_t ADC_IsActiveFlag_EOC(M0P_ADC_TypeDef *ADCx)
{
    return (REG_READBITS(ADCx->IFR, ADC_IFR_EOC) == ADC_IFR_EOC);    
}

/**
 ***********************************************************************************************
 ** \brief  清除ADC一次转换完成标志
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval NULL
 ***********************************************************************************************/
void ADC_ClearFlag_EOC(M0P_ADC_TypeDef *ADCx)
{
    REG_CLEARBITS(ADCx->ICR, ADC_ICR_EOC);    
}

/**
 ***********************************************************************************************
 ** \brief  ADC一次转换完成 中断使能 
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval NULL
 ***********************************************************************************************/
void ADC_EnableIT_EOC(M0P_ADC_TypeDef *ADCx)
{
    REG_SETBITS(ADCx->IER, ADC_IER_EOC);
}

/**
 ***********************************************************************************************
 ** \brief  ADC一次转换完成 中断禁止
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval NULL
 ***********************************************************************************************/
void ADC_DisableIT_EOC(M0P_ADC_TypeDef *ADCx)
{
    REG_CLEARBITS(ADCx->IER, ADC_IER_EOC);    
}

/**
 ***********************************************************************************************
 ** \brief  检查 ADC一次转换完成 是否已使能
 ** \param  [in] ADCx：ADC结构体变量

 ** \retval [out] 0：未开启； 非0：已开启
 ***********************************************************************************************/
uint32_t ADC_IsEnableIT_EOC(M0P_ADC_TypeDef *ADCx)
{
    return (uint32_t)(REG_READBITS(ADCx->IER, ADC_IER_EOC) == ADC_IER_EOC);    
}


//@} // AdcGroup


/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/


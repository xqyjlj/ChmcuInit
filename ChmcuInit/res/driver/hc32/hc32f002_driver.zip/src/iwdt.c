/*************************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.    
*
* This software is owned and published by: 
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND 
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC 
* components. This software is licensed by HDSC to be adapted only 
* for use in systems utilizing HDSC components. HDSC shall not be 
* responsible for misuse or illegal use of this software for devices not 
* supported herein. HDSC is providing this software "AS IS" and will 
* not be responsible for issues arising from incorrect user implementation 
* of the software.  
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS), 
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING, 
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED 
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED 
* WARRANTY OF NONINFRINGEMENT.  
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT, 
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT 
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, 
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR 
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA, 
* SAVINGS OR PROFITS, 
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED 
* FROM, THE SOFTWARE.  
*
* This software may be replicated in part or whole for the licensed use, 
* with the restriction that this Disclaimer and Copyright notice must be 
* included with each copy of this software, whether used in part or whole, 
* at all times.                        
*/
/******************************************************************************/
/** \file iwdt.c
 **
 ** iWDT function driver API.
 ** @link IWDT Group Some description @endlink
 **
 **   - 2020-05-17  1.0  CJ First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "iwdt.h"

/**
 ******************************************************************************
 ** \defgroup IWDTGroup
 **
 ******************************************************************************/
#define IWDT_KEY_VALUE              (0x5555U)
#define IWDT_KEY_START_VALUE        (0xCCCCU)
#define IWDT_KEY_RELOAD_VALUE       (0xAAAAU)
#define IWDT_KEY_STOP_BYPASS_1234   (0x1234U)
#define IWDT_KEY_STOP_BYPASS_5678   (0x5678U)
/******************************************************************************/
/* Local function prototypes ('static')                                       */
/******************************************************************************/

/**
 ******************************************************************************
 ** \brief  IWDT初始化函数
 **
 ** \param [in] pstcIwdtInit @ref stc_iwdt_init_t
 **
 ** \retval Ok
 **
 ******************************************************************************/
en_result_t IWDT_Init(stc_iwdt_init_t *pstcIwdtInit)
{
    REG_WRITE(M0P_IWDT->KR, IWDT_KEY_START_VALUE);
    REG_WRITE(M0P_IWDT->KR, IWDT_KEY_VALUE);
    while(REG_READBITS(M0P_IWDT->SR, IWDT_SR_PRSF|IWDT_SR_ARRF|IWDT_SR_WINRF)){;}
        
    REG_WRITE(M0P_IWDT->CR, pstcIwdtInit->u32Action |\
                            pstcIwdtInit->u32Prescaler);
    while(REG_READBITS(M0P_IWDT->SR, IWDT_SR_PRSF)){;}
    
    REG_WRITE(M0P_IWDT->ARR, pstcIwdtInit->u32ArrCounter);
    while(REG_READBITS(M0P_IWDT->SR, IWDT_SR_ARRF)){;}
    
    REG_WRITE(M0P_IWDT->WINR, pstcIwdtInit->u32Window);
    while(REG_READBITS(M0P_IWDT->SR, IWDT_SR_WINRF)){;}
    
    REG_WRITE(M0P_IWDT->KR, IWDT_KEY_RELOAD_VALUE);
    
    while(!REG_READBITS(M0P_IWDT->SR, IWDT_SR_RUN)){;}
    
    return Ok;
}

/**
 ******************************************************************************
 ** \brief  IWDT启动运行函数
 **
 ** \param [in] 无
 **
 ** \retval 无
 **
 ******************************************************************************/
void IWDT_Start(void)
{ 
    REG_WRITE(M0P_IWDT->KR, IWDT_KEY_START_VALUE);
}

/**
 ******************************************************************************
 ** \brief  IWDT停止运行函数
 **
 ** \param [in] 无
 **
 ** \retval 无
 **
 ******************************************************************************/
void IWDT_Stop(void)
{ 
    REG_WRITE(M0P_IWDT->KR, IWDT_KEY_STOP_BYPASS_1234);
    REG_WRITE(M0P_IWDT->KR, IWDT_KEY_STOP_BYPASS_5678);
}

/**
 ******************************************************************************
 ** \brief  IWDT 喂狗
 **
 ** \param [in] 无
 **
 ** \retval Ok
 **
 ******************************************************************************/
void IWDT_Feed(void)
{ 
    REG_WRITE(M0P_IWDT->KR, IWDT_KEY_RELOAD_VALUE);
}

/**
 ******************************************************************************
 ** \brief  IWDT溢出标志清除
 **
 ** \param [in] 无
 **
 ** \retval Ok
 **
 ******************************************************************************/
void IWDT_ClearOverFlag(void)
{
    REG_CLEARBITS(M0P_IWDT->SR, IWDT_SR_OV);
}

/**
 ******************************************************************************
 ** \brief  IWDT溢出标志获取
 **
 ** \param [in] 无
 **
 ** \retval TRUE or FALSE
 **
 ******************************************************************************/
boolean_t IWDT_GetOverFlag(void)
{
    if(REG_READBITS(M0P_IWDT->SR, IWDT_SR_OV))
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 ******************************************************************************
 ** \brief  IWDT 获取当前运行状态
 **
 ** \param [in] 无
 **
 ** \retval TRUE or FALSE
 **
 ******************************************************************************/
boolean_t IWDT_GetRunFlag(void)
{
    if(REG_READBITS(M0P_IWDT->SR, IWDT_SR_RUN))
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


//@} // IWDT Group

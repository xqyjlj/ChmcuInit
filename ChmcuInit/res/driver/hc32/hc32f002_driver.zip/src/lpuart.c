/*************************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file lpuart.c
 **
 ** LPUART function driver API.
 ** @link SampleGroup Some description @endlink
 **
 **   - 2020-05-17  1.0  xl First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "lpuart.h"
/**
 ******************************************************************************
 ** \addtogroup LPUART Group
 ******************************************************************************/
//@{
/******************************************************************************/
/* Local pre-processor symbols/macros ('#define')                             */
/******************************************************************************/

/******************************************************************************/
/* Local function prototypes ('static')                                       */
/******************************************************************************/

/******************************************************************************/
/* Local variable definitions ('static')                                       */
/******************************************************************************/

/**
 ******************************************************************************
 ** \brief  LPUART 初始化函数
 **
 ** \param [in] LPUARTx 通道指针 @ref M0P_LPUART_TypeDef
 ** \param [in] pstcLPUARTInit   @ref stc_lpuart_init_t
 **
 ** \retval OK配置成功
 ** \retval ErrorInvalidParameter配置失败
 ** \retval ErrorInvalidMode 波特率配置失败,或当前时钟无法计算出满足精度的波特率
 ******************************************************************************/
en_result_t LPUART_Init(M0P_LPUART_TypeDef* LPUARTx, stc_lpuart_init_t* pstcLPUARTInit)
{
    en_result_t enRet = Error;
    float32_t f32Scnt = 0;

    if(NULL == pstcLPUARTInit)
    {
        return ErrorInvalidParameter;
    }

    REG_CLEAR(LPUARTx->CR);
    REG_WRITE(LPUARTx->CR, pstcLPUARTInit->u32StopBits            |
                           pstcLPUARTInit->u32Parity              |
                           pstcLPUARTInit->u32FrameLength         |
                           pstcLPUARTInit->u32TransMode           |
                           pstcLPUARTInit->stcBaudRate.u32SclkSrc |
                           pstcLPUARTInit->u32HwControl);


    f32Scnt = (float32_t)(pstcLPUARTInit->stcBaudRate.u32Sclk) / (float32_t)(pstcLPUARTInit->stcBaudRate.u32BaudRate << 3u);
    REG_WRITE(LPUARTx->BRR, (uint16_t)(float32_t)(f32Scnt + 0.5f));

    if((((pstcLPUARTInit->stcBaudRate.u32Sclk) / (LPUARTx->BRR << 3u)) < pstcLPUARTInit->stcBaudRate.u32BaudRate*0.98) ||
       (((pstcLPUARTInit->stcBaudRate.u32Sclk) / (LPUARTx->BRR << 3u)) > pstcLPUARTInit->stcBaudRate.u32BaudRate*1.02))
    {
        enRet = ErrorInvalidMode;
    }
    else
    {
        enRet = Ok;
    }

    return enRet;
}

/**
 ******************************************************************************
 ** \brief  LPUART 查询发送
 **
 ** \param [in] LPUARTx 通道指针 @ref M0P_LPUART_TypeDef
 ** \param [in] pu8Data     发送数据buffer指针
 ** \param [in] u32Size     发送数据长度(字节数)
 ** \param [in] u32Timeout  发送超时时间
 **
 ** \retval OK发送完成
 ** \retval
 ******************************************************************************/
en_result_t LPUART_Transmit(M0P_LPUART_TypeDef* LPUARTx, uint8_t *pu8Data, uint32_t u32Size, uint32_t u32Timeout)
{

    while(u32Size)
    {
        while(!REG_READBITS(LPUARTx->ISR, LPUART_ISR_TXE)){;}
        REG_WRITE(LPUARTx->DR, *pu8Data);
        pu8Data++;
        u32Size--;
    }

    while(!REG_READBITS(LPUARTx->ISR, LPUART_ISR_TC)){;}
    REG_CLEARBITS(LPUARTx->ICR, LPUART_ICR_TC);

    return Ok;
}

/**
 ******************************************************************************
 ** \brief  UART中断发送
 **
 ** \param [in] pu8Data     发送数据指针
 **
 ** \retval OK发送完成
 ** \retval
 ******************************************************************************/
en_result_t LPUART_TransmitIT(M0P_LPUART_TypeDef* LPUARTx, uint8_t *pu8Data)
{
    REG_WRITE(LPUARTx->DR, *pu8Data);

    return Ok;
}

/**
 ******************************************************************************
 ** \brief  UART查询接收
 **
 ** \param [in] LPUARTx 通道指针 @ref M0P_LPUART_TypeDef
 ** \param [in] pu8Data     接收数据buffer指针
 ** \param [in] u32Size     接收数据长度(字节数)
 ** \param [in] u32Timeout  接收超时时间
 **
 ** \retval OK 接收完成
 ** \retval
 ******************************************************************************/
en_result_t LPUART_Receive(M0P_LPUART_TypeDef* LPUARTx, uint8_t *pu8Data, uint32_t u32Size, uint32_t u32Timeout)
{

    while(u32Size)
    {
        while(!REG_READBITS(LPUARTx->ISR, LPUART_ISR_RC)){;}
        *pu8Data = REG_READ(LPUARTx->DR);
        REG_CLEARBITS(LPUARTx->ICR, LPUART_ICR_RC);
        pu8Data++;
        u32Size--;
    }

    return Ok;
}

/**
 ******************************************************************************
 ** \brief  UART中断接收
 **
 ** \param [in] pu8Data     接收数据buffer指针
 **
 ** \retval OK 接收完成
 ** \retval
 ******************************************************************************/
en_result_t LPUART_ReceiveIT(M0P_LPUART_TypeDef* LPUARTx, uint8_t *pu8Data)
{
    *pu8Data = REG_READ(LPUARTx->DR);

    return Ok;
}

/**
 ******************************************************************************
 ** \brief  LPUART 中断使能
 **
 ** \param [in] LPUARTx 通道号
 ** \param [in] u32State 中断类型 @ref LPUART_Int_Type
 **
 ** \retval None
 ******************************************************************************/
void LPUART_EnableIrq(M0P_LPUART_TypeDef* LPUARTx, uint32_t u32State)
{
    REG_SETBITS(LPUARTx->CR, u32State);
}

/**
 ******************************************************************************
 ** \brief  LPUART 中断禁止
 **
 ** \param [in] LPUARTx 通道号
 ** \param [in] u32State 中断类型 @ref LPUART_Int_Type
 **
 ** \retval None
 ******************************************************************************/
void LPUART_DisableIrq(M0P_LPUART_TypeDef* LPUARTx, uint32_t u32State)
{
    REG_CLEARBITS(LPUARTx->CR, u32State);
}

/**
 ******************************************************************************
 ** \brief  LPUART 中断标志获取
 **
 ** \param [in] LPUARTx 通道号
 ** \param [in] u32State 中断标志 @ref LPUART_Flag_Type
 **
 ** \retval None
 ******************************************************************************/
uint32_t LPUART_GetFlag(M0P_LPUART_TypeDef* LPUARTx, uint32_t u32State)
{
    return REG_READBITS(LPUARTx->ISR, u32State);
}

/**
 ******************************************************************************
 ** \brief  LPUART 中断标志清除
 **
 ** \param [in] LPUARTx 通道号
 ** \param [in] u32State 中断标志 @ref LPUART_Flag_Type
 **
 ** \retval None
 ******************************************************************************/
void LPUART_ClearIrq(M0P_LPUART_TypeDef* LPUARTx, uint32_t u32State)
{
    REG_CLEARBITS(LPUARTx->ICR, u32State);
}

/**
 ******************************************************************************
 ** \brief  LPUART单线半双工模式使能
 **
 ** \param [in] LPUARTx 通道号
 **
 ** \retval None
 ******************************************************************************/
void LPUART_HdModeEnable(M0P_LPUART_TypeDef* LPUARTx)
{
    REG_SETBITS(LPUARTx->CR, LPUART_CR_HDSEL);
}


/**
 ******************************************************************************
 ** \brief  LPUART单线半双工模式关闭
 **
 ** \param [in] LPUARTx 通道号
 **
 ** \retval None
 ******************************************************************************/
void LPUART_HdModeDisable(M0P_LPUART_TypeDef* LPUARTx)
{
    REG_CLEARBITS(LPUARTx->CR, LPUART_CR_HDSEL);
}

/**
 ******************************************************************************
 ** \brief  LPUART通道多主机模式配置
 **
 ** \param [in] LPUARTx通道号
 ** \param [in] u8Addr    从机设备地址
 ** \param [in] u8AddrMsk 从机设备地址掩码
 **
 ** \retval None
 ******************************************************************************/
void LPUart_MultiModeConfig(M0P_LPUART_TypeDef* LPUARTx, uint8_t u8Addr, uint8_t u8AddrMsk)
{
    REG_SETBITS(LPUARTx->CR, LPUART_CR_ADRDET);
    REG_SETBITS(LPUARTx->ADDR, u8Addr);
    REG_SETBITS(LPUARTx->ADDRMASK, u8AddrMsk);
}

/**
 ******************************************************************************
 ** \brief  LPUART DR8置位
 **
 ** \param [in] LPUARTx 通道号
 **
 ** \retval None
 ******************************************************************************/
void LPUart_SetDR8(M0P_LPUART_TypeDef* LPUARTx)
{
    REG_SETBITS(LPUARTx->DR, LPUART_DR_DR8);
}

/**
 ******************************************************************************
 ** \brief  LPUART DR8清零
 **
 ** \param [in] LPUARTx 通道号
 **
 ** \retval None
 ******************************************************************************/
void LPUart_ClearDR8(M0P_LPUART_TypeDef* LPUARTx)
{
    REG_CLEARBITS(LPUARTx->DR, LPUART_DR_DR8);
}

/**
 ******************************************************************************
 ** \brief 获取DR8数值
 **
 ** \param [in] LPUARTx 通道号
 **
 ** \retval DR8
 **\retval  ErrorInvalidParameter配置失败
 ******************************************************************************/
boolean_t LPUart_GetDR8(M0P_LPUART_TypeDef* LPUARTx)
{
    return (REG_READBITS(LPUARTx->DR, LPUART_DR_DR8) ? TRUE : FALSE);
}


//@} // LPUARTGroup

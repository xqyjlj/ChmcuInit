/******************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/*****************************************************************************/
/** \file iwdt.h
 **
 ** Headerfile for IWDT functions
 **  
 **
 ** History:
 **   - 2020-07-01   Lx     First Version v1.0
 **
 *****************************************************************************/

#ifndef __IWDT_H__
#define __IWDT_H__

#include "ddl.h"


/**
 ******************************************************************************
 ** \defgroup WdtGroup Watchdog Timer (WDT)
 **
 ******************************************************************************/
//@{

/******************************************************************************/
/* Global pre-processor symbols/macros ('#define')                            */
/******************************************************************************/

/******************************************************************************
 * Global type definitions
 ******************************************************************************/
typedef struct stc_iwdt_init
{
    uint32_t u32Action;                 ///< 看门狗休眠模式及溢出后动作配置 @ref IWDT_Action
    uint32_t u32Prescaler;              ///< 看门狗计数时钟(RC10K)的分频 @ref IWDT_RC10K_Prescaler
    uint32_t u32Window;                 ///< 看门狗窗口值配置,取值范围必须为：[0u ~ 0xFFFu]
    uint32_t u32ArrCounter;             ///< 看门狗重载计数值配置,取值范围必须为：[0u ~ 0xFFFu]
                                        ///< u32Window < u32ArrCounter时, IWDT工作于窗口看门狗模式
                                        ///< u32Window ≥ u32ArrCounter时, IWDT工作于独立看门狗模式
} stc_iwdt_init_t;


/** @defgroup stc_iwdt_init_t IWDT_Action
  * @{
  */
#define IWDT_OVER_INT__SLEEPMODE_STOP           (IWDT_CR_ACTION | IWDT_CR_IE | IWDT_CR_PAUSE)
#define IWDT_OVER_RESET__SLEEPMODE_STOP         (IWDT_CR_PAUSE)
#define IWDT_OVER_INT__SLEEPMODE_RUN            (IWDT_CR_ACTION | IWDT_CR_IE)
#define IWDT_OVER_RESET__SLEEPMODE_RUN          (0U)

/**
  * @}
  */

/** @defgroup stc_iwdt_init_t IWDT_RC10K_Prescaler
  * @{
  */
#define IWDT_RC10K_DIV_4                        (0U)
#define IWDT_RC10K_DIV_8                        (1U)
#define IWDT_RC10K_DIV_16                       (2U)
#define IWDT_RC10K_DIV_32                       (3U)
#define IWDT_RC10K_DIV_64                       (4U)
#define IWDT_RC10K_DIV_128                      (5U)
#define IWDT_RC10K_DIV_256                      (6U)
#define IWDT_RC10K_DIV_512                      (7U)

/**
  * @}
  */

/** @defgroup IWDT_Flag
  * @{
  */
#define IWDT_FLAG_PRS                      IWDT_SR_PRSF
#define IWDT_FLAG_ARR                      IWDT_SR_ARRF
#define IWDT_FLAG_WINR                     IWDT_SR_WINRF
#define IWDT_FLAG_OVER                     IWDT_SR_OV
#define IWDT_FLAG_RUN                      IWDT_SR_RUN

/**
  * @}
  */

/**
  * @}
  */

///< IWDT 初始化配置
en_result_t IWDT_Init(stc_iwdt_init_t *pstcIwdtInit);

///< IWDT 开始和停止
void IWDT_Start(void);
void IWDT_Stop(void);
///< 喂狗处理
void IWDT_Feed(void);
///< IWDT 溢出标志获取
boolean_t IWDT_GetOverFlag(void);
///< IWDT 溢出标志清除
void IWDT_ClearOverFlag(void);
///< 运行状态获取
boolean_t IWDT_GetRunFlag(void);

//@} // IWDTGroup

#ifdef __cplusplus
#endif

#endif /* __IWDT_H__ */




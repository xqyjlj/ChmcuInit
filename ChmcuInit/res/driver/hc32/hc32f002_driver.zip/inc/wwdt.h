/******************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/*****************************************************************************/
/** \file wwdt.h
 **
 ** Headerfile for WWDT functions
 **  
 **
 ** History:
 **   - 2020-05-10   Cathy     First Version
 **
 *****************************************************************************/

#ifndef __WWDT_H__
#define __WWDT_H__

#include "ddl.h"


/**
 ******************************************************************************
 ** \defgroup WdtGroup Watchdog Timer (WDT)
 **
 ******************************************************************************/
//@{

/******************************************************************************/
/* Global pre-processor symbols/macros ('#define')                            */
/******************************************************************************/

/******************************************************************************
 * Global type definitions
 ******************************************************************************/
typedef struct stc_wwdt_init
{
    uint32_t u32Prescaler;              ///< 看门狗计数时钟(PCLK)的分频 @ref WWDT_PCLK_Prescaler
    uint32_t u32Window;                 ///< 看门狗窗口值配置,取值范围必须为：[0x40u ~ 0x7Fu]
    uint32_t u32Counter;                ///< 看门狗计数值配置,取值范围必须为：[0x40u ~ 0x7Fu]
                                        ///< u32Window < u32ArrCounter时, IWDT工作于窗口看门狗模式
                                        ///< u32Window ≥ u32ArrCounter时, IWDT工作于独立看门狗模式
    uint32_t u32PreOverInt;             ///< 预溢出中断控制 @ref WWDT_Pre_Over_Int
} stc_wwdt_init_t;

/** @defgroup stc_wwdt_init_t WWDT_PCLK_Prescaler
  * @{
  */
#define WWDT_PCLK_DIV_4096                        (0U << WWDT_CR1_PRS_Pos)
#define WWDT_PCLK_DIV_8192                        (1U << WWDT_CR1_PRS_Pos)
#define WWDT_PCLK_DIV_16384                       (2U << WWDT_CR1_PRS_Pos)
#define WWDT_PCLK_DIV_32768                       (3U << WWDT_CR1_PRS_Pos)
#define WWDT_PCLK_DIV_65536                       (4U << WWDT_CR1_PRS_Pos)
#define WWDT_PCLK_DIV_131072                      (5U << WWDT_CR1_PRS_Pos)
#define WWDT_PCLK_DIV_262144                      (6U << WWDT_CR1_PRS_Pos)
#define WWDT_PCLK_DIV_524288                      (7U << WWDT_CR1_PRS_Pos)

/**
  * @}
  */

/** @defgroup stc_wwdt_init_t WWDT_Pre_Over_Int
  * @{
  */
#define WWDT_PRE_INT_ENABLE                     WWDT_CR1_IE
#define WWDT_PRE_INT_DISABLE                    (0U)


/**
  * @}
  */

///< WWDT 初始化配置
en_result_t WWDT_Init(stc_wwdt_init_t *pstcWwdtInit);

///< WWDT 启动
void WWDT_Start(void);

///< 喂狗处理
void WWDT_Feed(uint32_t u32Cnt);

///< 获取当前计数值
uint32_t WWDT_GetCnt(void);

///< WWDT 溢出标志获取
boolean_t WWDT_GetPreOverFlag(void);
///< WWDT 溢出标志清除
void WWDT_ClearPreOverFlag(void);
///< 运行状态获取
boolean_t WWDT_GetRunFlag(void);

///< 执行WWDT 复位
void WWDT_Reset(void);

//@} // WWDTGroup

#ifdef __cplusplus
#endif

#endif /* __WWDT_H__ */




/******************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file adc.h
 **
 ** Header file for AD Converter functions
 ** @link ADC Group Some description @endlink
 **
 **   - 2020-05-26 Chenw    First Version
 **
 ******************************************************************************/

#ifndef __ADC_H__
#define __ADC_H__


/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "ddl.h"


/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C"
{
#endif

/**
 ******************************************************************************
 ** \defgroup AdcGroup AD Converter (ADC)
  **
 ******************************************************************************/
 
//@{

/******************************************************************************
 * Global definitions
 ******************************************************************************/
/** @defgroup Bit definition
  * @{
  */
#define ADC_CR0_SAM_0             (0x1UL<<ADC_CR0_SAM_Pos)
#define ADC_CR0_SAM_1             (0x2UL<<ADC_CR0_SAM_Pos)
                                 
#define ADC_CR0_REF_0             (0x1UL<<ADC_CR0_REF_Pos)
#define ADC_CR0_REF_1             (0x2UL<<ADC_CR0_REF_Pos)
                                 
#define ADC_CR0_CKDIV_0           (0x1UL<<ADC_CR0_CKDIV_Pos)
#define ADC_CR0_CKDIV_1           (0x2UL<<ADC_CR0_CKDIV_Pos)
#define ADC_CR0_CKDIV_2           (0x4UL<<ADC_CR0_CKDIV_Pos)
                                 
#define ADC_CR1_CHSEL_0           (0x1UL<<ADC_CR1_CHSEL_Pos)
#define ADC_CR1_CHSEL_1           (0x2UL<<ADC_CR1_CHSEL_Pos)
#define ADC_CR1_CHSEL_2           (0x4UL<<ADC_CR1_CHSEL_Pos)
#define ADC_CR1_CHSEL_3           (0x8UL<<ADC_CR1_CHSEL_Pos)

#define ADC_EXTTRIGGER_TRIGSEL_0  (0x1UL<<ADC_EXTTRIGGER_TRIGSEL_Pos)
#define ADC_EXTTRIGGER_TRIGSEL_1  (0x2UL<<ADC_EXTTRIGGER_TRIGSEL_Pos)
#define ADC_EXTTRIGGER_TRIGSEL_2  (0x4UL<<ADC_EXTTRIGGER_TRIGSEL_Pos)
#define ADC_EXTTRIGGER_TRIGSEL_3  (0x8UL<<ADC_EXTTRIGGER_TRIGSEL_Pos)
/**
  * @}
  */  

/** @defgroup ADC_SAMPLINGTIME_CYCLE_SELECTION  ADC采样周期选择
  * @{
  */
#define ADC_SAMPLINGTIME_6CYCLE   ((uint32_t)0x00000000U)
#define ADC_SAMPLINGTIME_8CYCLE   (ADC_CR0_SAM_0)
#define ADC_SAMPLINGTIME_11CYCLE  (ADC_CR0_SAM_1)
#define ADC_SAMPLINGTIME_12CYCLE  (ADC_CR0_SAM_0 | ADC_CR0_SAM_1)
/**
  * @}
  */  

/** @defgroup ADC_REF_VOLTAGE_SELECTION  ADC 参考电压选择
  * @{
  */
#define ADC_REF_VOLTAGE_EXREF     ((uint32_t)0x00000000U)         /*!< 外部参考电压ExRef(PB01) */
#define ADC_REF_VOLTAGE_AVCC      (ADC_CR0_REF_0)                /*!< AVCC电压                */
/**
  * @}
  */
  
/** @defgroup ADC_CLOCK_SELECTION  ADC 时钟选择
  * @{
  */
#define ADC_CLOCK_PCLK_DIV1       ((uint32_t)0x00000000U)
#define ADC_CLOCK_PCLK_DIV2       (ADC_CR0_CKDIV_0)
#define ADC_CLOCK_PCLK_DIV4       (ADC_CR0_CKDIV_1)
#define ADC_CLOCK_PCLK_DIV8       (ADC_CR0_CKDIV_0 | ADC_CR0_CKDIV_1)
#define ADC_CLOCK_PCLK_DIV16      (ADC_CR0_CKDIV_2)
#define ADC_CLOCK_PCLK_DIV32      (ADC_CR0_CKDIV_0 | ADC_CR0_CKDIV_2)
#define ADC_CLOCK_PCLK_DIV64      (ADC_CR0_CKDIV_1 | ADC_CR0_CKDIV_2)
#define ADC_CLOCK_PCLK_DIV128     (ADC_CR0_CKDIV_0 | ADC_CR0_CKDIV_1 | ADC_CR0_CKDIV_2)
/**
  * @}
  */

/** @defgroup ADC_EXINPUT_SELECTION  通道输入信号选择
  * @{
  */
#define ADC_EXINPUT_PC04          ((uint32_t)0x00000000U)
#define ADC_EXINPUT_PC06          (ADC_CR1_CHSEL_0)
#define ADC_EXINPUT_PD02          (ADC_CR1_CHSEL_1)
#define ADC_EXINPUT_PD03          (ADC_CR1_CHSEL_0 | ADC_CR1_CHSEL_1)
#define ADC_EXINPUT_PD04          (ADC_CR1_CHSEL_2)
#define ADC_EXINPUT_PD05          (ADC_CR1_CHSEL_0 | ADC_CR1_CHSEL_2)
#define ADC_EXINPUT_PD06          (ADC_CR1_CHSEL_1 | ADC_CR1_CHSEL_2)
#define ADC_EXINPUT_PA01          (ADC_CR1_CHSEL_0 | ADC_CR1_CHSEL_1 | ADC_CR1_CHSEL_2)
#define ADC_EXINPUT_PA02          (ADC_CR1_CHSEL_3)
#define ADC_EXINPUT_PB05          (ADC_CR1_CHSEL_0 | ADC_CR1_CHSEL_3)
#define ADC_EXINPUT_PB04          (ADC_CR1_CHSEL_1 | ADC_CR1_CHSEL_3)
#define ADC_EXINPUT_PB02          (ADC_CR1_CHSEL_0 | ADC_CR1_CHSEL_1 | ADC_CR1_CHSEL_3)
#define ADC_EXINPUT_PB01          (ADC_CR1_CHSEL_2 | ADC_CR1_CHSEL_3)
#define ADC_EXINPUT_PB00          (ADC_CR1_CHSEL_0 | ADC_CR1_CHSEL_2 | ADC_CR1_CHSEL_3)
#define ADC_EXINPUT_VREF_0p9      (ADC_CR1_CHSEL_1 | ADC_CR1_CHSEL_2 | ADC_CR1_CHSEL_3)
/**
  * @}
  */

/** @defgroup ADC_EXTTRIGGER_SELECTION  外部触发ADC转换源选择
  * @{
  */
#define ADC_EXTTRIGGER_ATIM3      ((uint32_t)0x00000000U)          /*!< ATimer3触发ADC转换 */
#define ADC_EXTTRIGGER_GTIM       (ADC_EXTTRIGGER_TRIGSEL_0)       /*!< GTimer溢出触发ADC转换 */
#define ADC_EXTTRIGGER_PB03       (ADC_EXTTRIGGER_TRIGSEL_1)       /*!< PB03中断触发ADC转换 */
#define ADC_EXTTRIGGER_PB04       (ADC_EXTTRIGGER_TRIGSEL_0 | ADC_EXTTRIGGER_TRIGSEL_1)        /*!< PB04中断触发ADC转换 */
#define ADC_EXTTRIGGER_PC03       (ADC_EXTTRIGGER_TRIGSEL_2)                                   /*!< PC03中断触发ADC转换 */
#define ADC_EXTTRIGGER_PC04       (ADC_EXTTRIGGER_TRIGSEL_0 | ADC_EXTTRIGGER_TRIGSEL_2)        /*!< PC04中断触发ADC转换 */
#define ADC_EXTTRIGGER_PD03       (ADC_EXTTRIGGER_TRIGSEL_1 | ADC_EXTTRIGGER_TRIGSEL_2)        /*!< PD03中断触发ADC转换 */
#define ADC_EXTTRIGGER_PD04       (ADC_EXTTRIGGER_TRIGSEL_0 | ADC_EXTTRIGGER_TRIGSEL_1 | ADC_EXTTRIGGER_TRIGSEL_2) /*!< PD04中断触发ADC转换 */
/**
  * @}
  */
  
/******************************************************************************
 ** Global type definitions
 *****************************************************************************/

/******************************************************************************
 ** Extern type definitions ('typedef')
 ******************************************************************************/

/**
 ******************************************************************************
 ** \brief  ADC初始化配置结构体
 *****************************************************************************/
typedef struct stc_adc_cfg
{    
    uint32_t        u32ClkDiv;                /*! ADC时钟选择  @ref ADC_CLOCK_SELECTION */
    uint32_t        u32SampCycleSel;          /*! ADC采样周期选择  @ref ADC_SAMPLINGTIME_CYCLE_SELECTION */
    uint32_t        u32RefVolSel;             /*! ADC参考电压选择  @ref ADC_REF_VOLTAGE_SELECTION */
    uint32_t        u32InputSource;           /*! ADC输入信号选择  @ref ADC_EXINPUT_SELECTION */
    uint32_t        u32ExtTriggerSource;      /*! ADC外部触发源选择  @ref ADC_EXTTRIGGER_SELECTION */
}stc_adc_cfg_t;



/******************************************************************************
 * Global variable definitions ('extern')
 ******************************************************************************/

/******************************************************************************
 * Global function prototypes (definition in C source)
 ******************************************************************************/
//ADC 初始化
en_result_t ADC_Init(M0P_ADC_TypeDef *ADCx, stc_adc_cfg_t* pstcAdcCfg);
void ADC_SetSampCycle(M0P_ADC_TypeDef *ADCx, uint32_t u32SampCycle);
uint32_t ADC_GetSampCycle(M0P_ADC_TypeDef *ADCx);
void ADC_SetRefVol(M0P_ADC_TypeDef *ADCx, uint32_t u32RefVol);
uint32_t ADC_GetRefVol(M0P_ADC_TypeDef *ADCx);
void ADC_SetClockDiv(M0P_ADC_TypeDef *ADCx, uint32_t u32ClockDiv);
uint32_t ADC_GetClockDiv(M0P_ADC_TypeDef *ADCx);
void ADC_StartSingleConversion(M0P_ADC_TypeDef *ADCx);
void ADC_StartContinuousConversion(M0P_ADC_TypeDef *ADCx);
void ADC_StopContinuousConversion(M0P_ADC_TypeDef *ADCx);
void ADC_SetInputSource(M0P_ADC_TypeDef *ADCx, uint32_t u32AdcSampInput);
uint32_t ADC_GetInputSource(M0P_ADC_TypeDef *ADCx);
uint32_t ADC_GetResult(M0P_ADC_TypeDef *ADCx);
void ADC_SetExtTriggerSource(M0P_ADC_TypeDef *ADCx, uint32_t u32ExtTriggerSource);
uint32_t ADC_GetExtTriggerSource(M0P_ADC_TypeDef *ADCx);
void ADC_Enable(M0P_ADC_TypeDef *ADCx);
void ADC_Disable(M0P_ADC_TypeDef *ADCx);
uint32_t ADC_IsEnable(M0P_ADC_TypeDef *ADCx);
uint32_t ADC_IsActiveFlag_EOC(M0P_ADC_TypeDef *ADCx);
void ADC_ClearFlag_EOC(M0P_ADC_TypeDef *ADCx);
void ADC_EnableIT_EOC(M0P_ADC_TypeDef *ADCx);
void ADC_DisableIT_EOC(M0P_ADC_TypeDef *ADCx);
uint32_t ADC_IsEnableIT_EOC(M0P_ADC_TypeDef *ADCx);


//@}
#ifdef __cplusplus
}
#endif

#endif /* __ADC_H__ */
/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/

/******************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED   , ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/*****************************************************************************/
/** \file spi.h
 **
 ** Headerfile for SPI functions
 **  
 **
 ** History:
 **   - 2020-06-17  1.0  Chenw     First Version
 **
 *****************************************************************************/
#ifndef __SPI_H__
#define __SPI_H__

/******************************************************************************
 * Include files
 *****************************************************************************/
#include "ddl.h"


/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C"
{
#endif

//@{

/******************************************************************************
 * Global type definitions
 *****************************************************************************/
/** @defgroup Bit definition
  * @{
  */
#define  SPI_CR0_BRR_0                   (0x1 << SPI_CR0_BRR_Pos)
#define  SPI_CR0_BRR_1                   (0x2 << SPI_CR0_BRR_Pos)
#define  SPI_CR0_BRR_2                   (0x4 << SPI_CR0_BRR_Pos)

#define  SPI_CR0_WIDTH_0                 (0x1 << SPI_CR0_WIDTH_Pos)
#define  SPI_CR0_WIDTH_1                 (0x2 << SPI_CR0_WIDTH_Pos)
#define  SPI_CR0_WIDTH_2                 (0x4 << SPI_CR0_WIDTH_Pos)
#define  SPI_CR0_WIDTH_3                 (0x8 << SPI_CR0_WIDTH_Pos)

#define  SPI_CR0_CM_0                    (0x1 << SPI_CR0_CM_Pos)
#define  SPI_CR0_CM_1                    (0x2 << SPI_CR0_CM_Pos)
/**
  * @}
  */
  
/** @defgroup SPI_BAUDRATE_SELECTION  SPI主机模式波特率选择
  * @{
  */
#define  SPI_BAUDRATE_PCLK_DIV2          (0x00000000UL)
#define  SPI_BAUDRATE_PCLK_DIV4          (SPI_CR0_BRR_0)
#define  SPI_BAUDRATE_PCLK_DIV8          (SPI_CR0_BRR_1)
#define  SPI_BAUDRATE_PCLK_DIV16         (SPI_CR0_BRR_0 | SPI_CR0_BRR_1)
#define  SPI_BAUDRATE_PCLK_DIV32         (SPI_CR0_BRR_2)
#define  SPI_BAUDRATE_PCLK_DIV64         (SPI_CR0_BRR_0 | SPI_CR0_BRR_2)
#define  SPI_BAUDRATE_PCLK_DIV128        (SPI_CR0_BRR_1 | SPI_CR0_BRR_2)
/**
  * @}
  */  
  
/** @defgroup SPI_CLOCK_PHASE_SELECTION  SPI串行时钟相位选择
  * @{
  */
#define  SPI_CLOCK_PHASE_1EDGE           (0x00000000UL)
#define  SPI_CLOCK_PHASE_2EDGE           (SPI_CR0_CPHA)
/**
  * @}
  */  
  
/** @defgroup SPI_CLOCK_POLARITY_SELECTION  SPI串行时钟极性选择
  * @{
  */
#define  SPI_CLOCK_POLARITY_LOW          (0x00000000UL)
#define  SPI_CLOCK_POLARITY_HIGH         (SPI_CR0_CPOL)
/**
  * @}
  */  
  
/** @defgroup SPI_MODE_SELECTION  SPI 工作模式选择
  * @{
  */
#define  SPI_MODE_SLAVE                  (0x00000000UL)        /*!< 从机模式 */
#define  SPI_MODE_MASTER                 (SPI_CR0_MSTR)        /*!< 主机模式 */
/**
  * @}
  */  
  
/** @defgroup SPI_BIT_ORDER_SELECTION  SPI 串行数据高低位顺序发送 选择
  * @{
  */
#define  SPI_MSB_FIRST                   (0x00000000UL)
#define  SPI_LSB_FIRST                   (SPI_CR0_LSBF)
/**
  * @}
  */  
  
/** @defgroup SPI_DATAWIDTH_SELECTION  每帧的数据宽度选择
  * @{
  */
#define  SPI_DATAWIDTH_4BIT              (SPI_CR0_WIDTH_0 | SPI_CR0_WIDTH_1)
#define  SPI_DATAWIDTH_5BIT              (SPI_CR0_WIDTH_2)
#define  SPI_DATAWIDTH_6BIT              (SPI_CR0_WIDTH_0 | SPI_CR0_WIDTH_2)
#define  SPI_DATAWIDTH_7BIT              (SPI_CR0_WIDTH_1 | SPI_CR0_WIDTH_2)
#define  SPI_DATAWIDTH_8BIT              (SPI_CR0_WIDTH_0 | SPI_CR0_WIDTH_1 | SPI_CR0_WIDTH_2)
#define  SPI_DATAWIDTH_9BIT              (SPI_CR0_WIDTH_3)
#define  SPI_DATAWIDTH_10BIT             (SPI_CR0_WIDTH_0 | SPI_CR0_WIDTH_3)
#define  SPI_DATAWIDTH_11BIT             (SPI_CR0_WIDTH_1 | SPI_CR0_WIDTH_3)
#define  SPI_DATAWIDTH_12BIT             (SPI_CR0_WIDTH_0 | SPI_CR0_WIDTH_1 | SPI_CR0_WIDTH_3)
#define  SPI_DATAWIDTH_13BIT             (SPI_CR0_WIDTH_2 | SPI_CR0_WIDTH_3)
#define  SPI_DATAWIDTH_14BIT             (SPI_CR0_WIDTH_0 | SPI_CR0_WIDTH_2 | SPI_CR0_WIDTH_3)
#define  SPI_DATAWIDTH_15BIT             (SPI_CR0_WIDTH_1 | SPI_CR0_WIDTH_2 | SPI_CR0_WIDTH_3)
#define  SPI_DATAWIDTH_16BIT             (SPI_CR0_WIDTH_0 | SPI_CR0_WIDTH_1 | SPI_CR0_WIDTH_2 | SPI_CR0_WIDTH_3)
/**
  * @}
  */  
  
/** @defgroup SPI_NSS_CFG  NSS片选信号配置
  * @{
  */
#define  SPI_NSS_HARD_INPUT              (0x00000000UL)           /*!< 外部IO管脚决定NSS信号    */
#define  SPI_NSS_HARD_OUTPUT             (SPI_CR0_SSM)            /*!< NSS信号由IO管脚输出    */
#define  SPI_NSS_SOFT                    (SPI_CR0_SSM)            /*!< SSI寄存器值决定NSS从机选择信号    */
/**
  * @}
  */  
  
/** @defgroup SPI_NSS_SOFT_VAL  SPI SSI的值，只有SSM=1时有效
  * @{
  */
#define  SPI_NSS_CONFIG_ENABLE           (0x00000000UL)        /*!< 片选使能    */
#define  SPI_NSS_CONFIG_DISABLE          (SPI_SSI_SSI)         /*!< 片选禁止    */
/**
  * @}
  */  
  
/** @defgroup SPI_NSS_EXT_INPUT_LEVEL  SPI NSS管脚上的电平,如果没有使能NSS外部硬件输入，读取此值无意义
  * @{
  */
#define  SPI_NSS_EXT_INPUT_LOW_LEVEL     (0x00000000UL)        /*!< NSS管脚上输入的是低电平    */
#define  SPI_NSS_EXT_INPUT_HIGH_LEVEL    (SPI_SR_SSLVL)        /*!< NSS管脚上输入的是高电平    */
/**
  * @}
  */  
  
/** @defgroup SPI_TRANSFER_DIRECTION_SELECTION  SPI通讯方式选择
  * @{
  */    
#define  SPI_FULL_DUPLEX                 (0x00000000UL)                   /*!< 全双工双向    */
#define  SPI_SIMPLE_TX                   (SPI_CR0_CM_0)                   /*!< 单工只发    */
#define  SPI_SIMPLE_RX                   (SPI_CR0_CM_1)                   /*!< 单工只收    */
#define  SPI_HALF_DUPLEX                 (SPI_CR0_CM_0 | SPI_CR0_CM_1)    /*!< 单线半双工    */
/**
  * @}
  */  
  
/** @defgroup SPI_HALF_DUPLEX_DIRECTION_SELECTION  SPI半双工传输方向选择
  * @{
  */
#define  SPI_HALF_DUPLEX_RX              (0x00000000UL)        /*!< 单线半双工只收    */
#define  SPI_HALF_DUPLEX_TX              (SPI_HDOE_HDOE)       /*!< 单线半双工只发    */
/**
  * @}
  */  
  
/** @defgroup SPI_IT_SELECTION  SPI中断使能选择
  * @{
  */
#define SPI_IT_TXE                       (SPI_CR1_TXEIE)      /*!< 发送缓冲空中断  */
#define SPI_IT_RXNE                      (SPI_CR1_RXNEIE)     /*!< 接收缓冲非空中断  */
#define SPI_IT_SSF                       (SPI_CR1_SSFIE)      /*!< 从机选择输入下降沿中断  */
#define SPI_IT_SSR                       (SPI_CR1_SSRIE)      /*!< 从机选择输入上升沿中断  */
#define SPI_IT_UDF                       (SPI_CR1_UDFIE)      /*!< 从机模式下发送缓冲下溢错误中断  */
#define SPI_IT_OVF                       (SPI_CR1_OVFIE)      /*!< 接收缓冲上溢错误  */
#define SPI_IT_SSERR                     (SPI_CR1_SSERRIE)    /*!< 从机模式下的从机选择错误中断  */
#define SPI_IT_MODF                      (SPI_CR1_MODFIE)     /*!< 模式错误中断  */
/**
  * @}
  */  
  
/** @defgroup SPI_FLAG_SELECTION  SPI中断标志位选择
  * @{
  */
#define SPI_FLAG_TXE                     (SPI_SR_TXE)         /*!< 发送缓冲空 标志  */
#define SPI_FLAG_RXNE                    (SPI_SR_RXNE)        /*!< 接收缓冲非空 标志  */
#define SPI_FLAG_SSF                     (SPI_SR_SSF)         /*!< 从机选择输入下降沿 标志  */
#define SPI_FLAG_SSR                     (SPI_SR_SSR)         /*!< 从机选择输入上升沿 标志  */
#define SPI_FLAG_UDF                     (SPI_SR_UDF)         /*!< 从机模式下发送缓冲下溢错误 标志  */
#define SPI_FLAG_OVF                     (SPI_SR_OVF)         /*!< 接收缓冲上溢错误 标志  */
#define SPI_FLAG_SSERR                   (SPI_SR_SSERR)       /*!< 从机模式下的从机选择错误 标志  */
#define SPI_FLAG_MODF                    (SPI_SR_MODF)        /*!< 模式错误 标志  */
#define SPI_FLAG_BUSY                    (SPI_SR_BUSY)        /*!< 总线忙 标志  */
/**                                                          
  * @}                                                       
  */                                                         
                                                             
/** @defgroup SPI_CLEAR_SELECTION  SPI清除中断标志位选择     
  * @{                                                       
  */                                                         
#define SPI_CLEAR_RXNE                   (SPI_ICR_RXNE)        /*!< 清除 接收缓冲非空 标志  */
#define SPI_CLEAR_SSF                    (SPI_ICR_SSF)         /*!< 清除 从机选择输入下降沿 标志  */
#define SPI_CLEAR_SSR                    (SPI_ICR_SSR)         /*!< 清除 从机选择输入上升沿 标志  */
#define SPI_CLEAR_UDF                    (SPI_ICR_UDF)         /*!< 清除 从机模式下发送缓冲下溢错误 标志  */
#define SPI_CLEAR_OVF                    (SPI_ICR_OVF)         /*!< 清除 接收缓冲上溢错误 标志  */
#define SPI_CLEAR_SSERR                  (SPI_ICR_SSERR)       /*!< 清除 从机模式下的从机选择错误 标志  */
#define SPI_CLEAR_MODF                   (SPI_ICR_MODF)        /*!< 清除 模式错误 标志  */
/**
  * @}
  */
  
 /**
 ******************************************************************************
 ** \brief SPI 功能通道选择设置
 ******************************************************************************/ 

/**
 ******************************************************************************
 ** \brief SPI 总体配置结构体
 *****************************************************************************/
typedef struct stc_spi_init
{
    uint32_t      u32Mode;               /*! 主从模式选择  @ref SPI_MODE_SELECTION */
    uint32_t      u32TransferDirection;  /*! 通信方式选择  @ref SPI_TRANSFER_DIRECTION_SELECTION */
    uint32_t      u32DataWidth;          /*! 每帧的数据宽度  @ref SPI_DATAWIDTH_SELECTION */
    uint32_t      u32CPOL;               /*! 时钟极性选择  @ref SPI_CLOCK_POLARITY_SELECTION */
    uint32_t      u32CPHA;               /*! 时钟相位选择  @ref SPI_CLOCK_PHASE_SELECTION */
    uint32_t      u32NSS;                /*! 配置NSS片选信号是硬件控制还是软件控制  @ref SPI_NSS_CFG */
    uint32_t      u32BaudRate;           /*! 波特率分频  @ref SPI_BAUDRATE_SELECTION */
    uint32_t      u32BitOrder;           /*! 数据传输，高低位顺序选择  @ref SPI_BIT_ORDER_SELECTION */
}stc_spi_init_t;

/******************************************************************************
 * Global variable declarations ('extern', definition in C source)
 *****************************************************************************/

/******************************************************************************
 * Global function prototypes (definition in C source)
 *****************************************************************************/ 
 
en_result_t Spi_Init(M0P_SPI_TypeDef* SPIx,stc_spi_init_t* pstcInitCfg);
void SPI_Enable(M0P_SPI_TypeDef *SPIx);
void SPI_Disable(M0P_SPI_TypeDef *SPIx);
uint32_t SPI_IsEnable(M0P_SPI_TypeDef *SPIx);
void SPI_EnableDMA(M0P_SPI_TypeDef *SPIx, uint32_t u32EnDMA);
void SPI_DisableDMA(M0P_SPI_TypeDef *SPIx, uint32_t u32DMA);
void SPI_SetBaudRate(M0P_SPI_TypeDef *SPIx, uint32_t u32BaudRate);
uint32_t SPI_GetBaudRate(M0P_SPI_TypeDef *SPIx);
void SPI_SetClockPhase(M0P_SPI_TypeDef *SPIx, uint32_t u32ClockPhase);
uint32_t SPI_GetClockPhase(M0P_SPI_TypeDef *SPIx);
void SPI_SetClockPolarity(M0P_SPI_TypeDef *SPIx, uint32_t u32ClockPolarity);
uint32_t SPI_GetClockPolarity(M0P_SPI_TypeDef *SPIx);
void SPI_SetMode(M0P_SPI_TypeDef *SPIx, uint32_t u32Mode);
uint32_t SPI_GetMode(M0P_SPI_TypeDef *SPIx);
void SPI_SetTransferBitOrder(M0P_SPI_TypeDef *SPIx, uint32_t u32TransferBitOrder);
uint32_t SPI_GetTransferBitOrder(M0P_SPI_TypeDef *SPIx);
void SPI_SetDataWidth(M0P_SPI_TypeDef *SPIx, uint32_t u32DataWidth);
uint32_t SPI_GetDataWidth(M0P_SPI_TypeDef *SPIx);
void SPI_SetNSSMode(M0P_SPI_TypeDef *SPIx, uint32_t u32NSSMode);
uint32_t SPI_GetNSSMode(M0P_SPI_TypeDef *SPIx);
void SPI_SlaveNSSConfig(M0P_SPI_TypeDef *SPIx, uint32_t u32NSSCfg);
void SPI_MasterNSSOutput(M0P_SPI_TypeDef *SPIx, uint32_t u32NSSCfg);
uint32_t SPI_GetNSSSoftValue(M0P_SPI_TypeDef *SPIx);
uint32_t SPI_GetNSSExtInput(M0P_SPI_TypeDef *SPIx);
void SPI_SetTransferDirection(M0P_SPI_TypeDef *SPIx, uint32_t u32TransferDirection);
uint32_t SPI_GetTransferDirection(M0P_SPI_TypeDef *SPIx);
void SPI_SetHalfDuplexDirection(M0P_SPI_TypeDef *SPIx, uint32_t u32TransferDirection);
uint32_t SPI_GetHalfDuplexDirection(M0P_SPI_TypeDef *SPIx);
void SPI_EnableIT(M0P_SPI_TypeDef* SPIx, uint32_t u32ITEn);
void SPI_DisableIT(M0P_SPI_TypeDef* SPIx, uint32_t u32IT);
uint32_t SPI_IsEnableIT(M0P_SPI_TypeDef* SPIx, uint32_t u32IT);
uint32_t SPI_IsActiveFlag(M0P_SPI_TypeDef* SPIx, uint32_t u32IT);
void SPI_ClearFlag(M0P_SPI_TypeDef* SPIx, uint32_t u32IT);
void SPI_ClearFlag_ALL(M0P_SPI_TypeDef* SPIx);
void SPI_SetFlag_TXE(M0P_SPI_TypeDef* SPIx);
void SPI_TransmitData(M0P_SPI_TypeDef *SPIx, uint16_t u16Data);
uint32_t SPI_ReceiveData(M0P_SPI_TypeDef *SPIx);

//@} // Spi Group

#ifdef __cplusplus
}
#endif

#endif /* __SPI_H__ */
/******************************************************************************
 * EOF (not truncated)
 *****************************************************************************/


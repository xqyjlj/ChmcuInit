/******************************************************************************
* Copyright (C) 2020, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/*****************************************************************************/
/** \file i2c.h
 **
 ** Headerfile for I2C functions
 **  
 **
 ** History:
 **   - 2020-07-1   Chenw    First Version
 **
 *****************************************************************************/

#ifndef __I2C_H__
#define __I2C_H__

#include "ddl.h"


/**
 *******************************************************************************
 ** \defgroup I2cGroup Inter-Integrated Circuit (I2C)
 **
 **
 ******************************************************************************/
//@{

/******************************************************************************/
/* Global pre-processor symbols/macros ('#define')                            */
/******************************************************************************/

/** @defgroup I2C_FILTER_MODE  滤波方式选择，，作为主机I2C_BRR值大于9，或者作为
 ** 从机PCLK与SCL频率比值大于30时，建议使用I2C_FILTER_ADVANCE
  * @{
  */
#define   I2C_FILTER_ADVANCE   (0x00000000UL)    //更高的抗干扰性能
#define   I2C_FILTER_SIMPLE    (I2C_CR_FLT)      //更快的通信滤波
/**
  * @}
  */
  
/** @defgroup I2C_ACKNOWLEDGE_CFG  应答控制
  * @{
  */
#define   I2C_NACK   (0x00000000UL)    //在应答阶段发送ACK
#define   I2C_ACK    (I2C_CR_AA)       //在应答阶段发送NAK
/**
 * @}
 */
  
/** @defgroup I2C_START_CFG  向总线发送start控制
  * @{
  */
#define   I2C_START_DISABLE    (0x00000000UL)       //禁止向总线发送start
#define   I2C_START_ENABLE     (I2C_CR_STA)         //向总线发送start
/**
 * @}
 */
  
/** @defgroup I2C_STOP_CFG  向总线发送stop控制
  * @{
  */
#define   I2C_STOP_DISABLE    (0x00000000UL)      //禁止向总线发送stop
#define   I2C_STOP_ENABLE     (I2C_CR_STO)        //向总线发送stop
/**
 * @}
 */
  
/** @defgroup I2C_BROADCAST_CFG  向总线发送stop控制
  * @{
  */
#define   I2C_BROADCAST_DISABLE   (0x00000000UL)    //禁止广播地址应答
#define   I2C_BROADCAST_ENABLE    (I2C_ADDR0_GC)    //使能广播地址应答
/**
 * @}
 */
 
/** @defgroup I2C_BUS_ADDR_MATCH  总线设备地址匹配
  * @{
  */
#define   I2C_BUS_ADDR_MATCH_NONE    (0x00000000UL)        //无从地址与总线上的设备地址匹配
#define   I2C_BUS_ADDR_MATCH_ADDR0   (I2C_MATCH_AD0F)      //设备从地址ADDR0与总线上的设备地址匹配
#define   I2C_BUS_ADDR_MATCH_ADDR1   (I2C_MATCH_AD1F)      //设备从地址ADDR1与总线上的设备地址匹配
#define   I2C_BUS_ADDR_MATCH_ADDR2   (I2C_MATCH_AD2F)      //设备从地址ADDR2与总线上的设备地址匹配
/**
 * @}
 */
/******************************************************************************
 * Global type definitions
 ******************************************************************************/

/**
 ******************************************************************************
 ** \brief I2C从机初始化配置结构
 *****************************************************************************/
typedef struct stc_i2c_slave_init_cfg
{
    uint8_t         u8SlaveAddr0;           /*! 从机地址0  取值范围0 ~ 127 */
    uint8_t         u8SlaveAddr1;           /*! 从机地址1  取值范围0 ~ 127 */
    uint8_t         u8SlaveAddr2;           /*! 从机地址2  取值范围0 ~ 127 */
    uint32_t        u32Filter;              /*! 滤波配置  @ref I2C_FILTER_MODE */
    uint32_t        u32BroadcastEn;         /*! 广播地址使能  @ref I2C_BROADCAST_CFG */
}stc_i2c_slave_init_cfg_t;

/**
 ******************************************************************************
 ** \brief I2C主机初始化配置结构
 *****************************************************************************/
typedef struct stc_i2c_master_init_cfg
{
    uint32_t        u32Pclk;                /*! pclk时钟频率 通过调用SYSCTRL_GetPCLK()函数可以获取 */
    uint32_t        u32BaudRate;            /*! 波特率 */
}stc_i2c_master_init_cfg_t;

/******************************************************************************
 * Global variable declarations ('extern', definition in C source)
 *****************************************************************************/

/******************************************************************************
 * Global function prototypes (definition in C source)
 *****************************************************************************/ 
 
 //I2C初始化函数
en_result_t I2C_MasterInit(M0P_I2C_TypeDef* I2Cx, stc_i2c_master_init_cfg_t *pstcMasterInitCfg);
en_result_t I2C_SlaveInit(M0P_I2C_TypeDef* I2Cx, stc_i2c_slave_init_cfg_t *pstcSlaveInitCfg);
void I2C_EnableBaud(M0P_I2C_TypeDef *I2Cx);
void I2C_DisableBaud(M0P_I2C_TypeDef *I2Cx);
uint32_t I2C_IsEnableBaud(M0P_I2C_TypeDef *I2Cx);
void I2C_SetBaud(M0P_I2C_TypeDef *I2Cx, uint32_t u32Baud);
uint32_t I2C_GetBaud(M0P_I2C_TypeDef *I2Cx);
void I2C_SetFilter(M0P_I2C_TypeDef *I2Cx, uint32_t u32Filter);
uint32_t I2C_GetFilter(M0P_I2C_TypeDef *I2Cx);
uint32_t I2C_IsActiveFlag_SI(M0P_I2C_TypeDef *I2Cx);
void I2C_ClearFlag_SI(M0P_I2C_TypeDef *I2Cx);
void I2C_SetAck(M0P_I2C_TypeDef *I2Cx, uint32_t u32Ack);
uint32_t I2C_GetAck(M0P_I2C_TypeDef *I2Cx);
void I2C_SetStop(M0P_I2C_TypeDef *I2Cx, uint32_t u32Stop);
void I2C_SetStart(M0P_I2C_TypeDef *I2Cx, uint32_t u32Start);
uint32_t I2C_GetStart(M0P_I2C_TypeDef *I2Cx);
void I2C_Enable(M0P_I2C_TypeDef *I2Cx);
void I2C_Disable(M0P_I2C_TypeDef *I2Cx);
uint32_t I2C_IsEnable(M0P_I2C_TypeDef *I2Cx);
void I2C_WriteByte(M0P_I2C_TypeDef *I2Cx, uint8_t u8Data);
uint8_t I2C_ReadByte(M0P_I2C_TypeDef *I2Cx);
uint8_t I2C_GetBusState(M0P_I2C_TypeDef *I2Cx);
void I2C_EnableBroadcast(M0P_I2C_TypeDef *I2Cx);
void I2C_DisableBroadcast(M0P_I2C_TypeDef *I2Cx);
uint32_t I2C_IsEnableBroadcast(M0P_I2C_TypeDef *I2Cx);
void I2C_SetSlaveAddr0(M0P_I2C_TypeDef *I2Cx, uint32_t u32Addr);
uint32_t I2C_GetSlaveAddr0(M0P_I2C_TypeDef *I2Cx);
void I2C_SetSlaveAddr1(M0P_I2C_TypeDef *I2Cx, uint32_t u32Addr);
uint32_t I2C_GetSlaveAddr1(M0P_I2C_TypeDef *I2Cx);
void I2C_SetSlaveAddr2(M0P_I2C_TypeDef *I2Cx, uint32_t u32Addr);
uint32_t I2C_GetSlaveAddr2(M0P_I2C_TypeDef *I2Cx);
uint32_t I2C_GetBusMatchSlaveAddr(M0P_I2C_TypeDef *I2Cx);
 
//@} // I2cGroup

#ifdef __cplusplus
#endif

#endif /* __I2C_H__ */
/******************************************************************************
 * EOF (not truncated)
 *****************************************************************************/


